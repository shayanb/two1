# flake8: noqa
"""Bitserv implementation for Flask."""
from .decorator import Payment
