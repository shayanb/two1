"""Bitserv implementation for Flask."""
from .decorator import Payment
