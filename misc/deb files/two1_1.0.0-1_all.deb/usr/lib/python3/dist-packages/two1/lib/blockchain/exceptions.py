class DataProviderUnavailableError(Exception):
    pass


class DataProviderError(Exception):
    pass
